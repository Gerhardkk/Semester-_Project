#include <iostream>
using namespace std;
string opin;
string npin;
string code;
string pin="0000";
int attempts=0;
double acc;
int acc_b=1000;
int op;
int main(){
	//SINCE THIS FOR EDUCATIONAL PURPOSE WHEN PROMPTED FOR ANY PIN CODE, INPUT (0000).
	start:
	cout<<"------SANTEX USSD NETWORK SYSTEM------"<<endl;
    cout<<"      CHECK CREDIT BALANCE--*124#"<<endl;
	cout<<"      VIEW YOUR PROFILE--*110#"<<endl;
	cout<<"      TRANSACTION HISTORY--*111#"<<endl;
	cout<<"      ACCOUNT RECHARGE--*550#"<<endl;
	cout<<"      BUY DATA--*533#"<<endl;
	cout<<"      CASH DEPOSIT--*200#"<<endl;
	cout<<"      CHANGE MOBILE MONEY PIN--*300#"<<endl;
	cout<<"      SEND AIRTIME--*530#"<<endl;
	cout<<"      TAKE A LOAN--*400#"<<endl;
	cout<<"      SAVINGS PLAN--*800#"<<endl;
	cout<<"      ENTER ANY CODE FROM THE ABOVE:"<<endl;
	cin>>code;

while(attempts<=4){
	
	if(code!="*124#"&&code!="*110#"&&code!="*111#"&&code!="*550#"&&code!="*533#"&&code!="*200#"&&code!="*300#"&&code!="*530#"&&code!="*400#"&&code!="*800#"){
		cout<<"Unrecognized Code...Please check and try again"<<endl;
		goto start;
	}
	

	//CHECKING CREDIT BALANCE
	if(code=="*124#"){
		cout<<"Account:Ghc4.00"<<endl;
		cout<<"Sms:5400Units"<<endl;
		cout<<"Voice Balance:180Mins"<<endl;
		cout<<"Internet bundle: 2GB"<<endl;
		cout<<"Social Media: 400MB"<<endl;
		break;
	}
	//VIEWING PROFILE
	if(code=="*110#"){
		cout<<"Enter your pin"<<endl;
		cin>>npin;
	if(npin==pin){
		cout<<"GERHARD ANTWI"<<endl;
		cout<<"User since 2019"<<endl;
		cout<<"Registered Mobile Money User"<<endl;
		cout<<"Activated Sim Card"<<endl;
		cout<<"UserID:1234"<<endl;
		break;
	}
	else{
		cout<<"Invalid Option"<<endl;
		attempts++;
		if(attempts==4){
			cout<<"Maximum number of attempts reached.."<<endl;
			break;
		}
	}
		
	}
	
	//TRANSACTION HISTORY
	if(code=="*111#"){
		cout<<"Enter your pin"<<endl;
		cin>>npin;
	if(npin==pin){
		cout<<"Ghc 100 was received from GLOBAL VENTURES on 30th January 2021"<<endl;
		cout<<"Ghc 200 was sent to Emelia Quaye on 28th february 2021"<<endl;
		cout<<"Ghc 3000 was received from BLUE BAND ROYALS on 29th April 2021"<<endl;
		cout<<"Ghc 900 was received from Ophelia Okyere on 10th June 2021"<<endl;
		cout<<"Ghc 500 was sent to Calvin klein on 6th August 2021"<<endl;
		break;
	 }
	 else{
	 	cout<<"Invalid Option"<<endl;
	 	attempts++;
	 	if(attempts==4){
	 		cout<<"Maximum number of attempts reached"<<endl;
	 		break;
		 }
	 	
	 }
	}
	//ACCOUNT RECHARGE
	if(code=="*550#"){
		cout<<"Enter Your Mobile Money Pin To Confirm Purchase"<<endl;
		cin>>npin;
	if(npin==pin){
		cout<<"Enter Amount:"<<endl;
		cin>>acc;
		if(acc>acc_b){
			cout<<"Not Enough Funds..."<<endl;
			break;
		}
	 if(acc<=acc_b){
			cout<<"You have Purchased Ghc "<<acc<<" worth of airtime"<<" your remaining balance is Ghc "<<acc_b-acc<<endl;
			break;
		}
	}
	else{
		cout<<"Invalid Option"<<endl;
		attempts++;
		if(attempts==4){
			cout<<"Maximum number of attempts..."<<endl;
			break;
		}
	}
  }
  //BUYING DATA
  if(code=="*533#"){
		cout<<"Select Your Data Package"<<endl;
		cout<<"1) 2GB--Ghc 15.00"<<endl;
		cout<<"2) 1GB--Ghc 10.00"<<endl;
		cout<<"3) 500MB--Ghc 5.00"<<endl;
		cin>>op;
	if(op==1){
		cout<<"You Have successfully purchased 2GB worth of data"<<endl;
		break;
	}
	if(op==2){
		cout<<"You have successfully purchased 1GB worth of data"<<endl;
		break;
	}
	if(op==3){
		cout<<"Your have successfully purchased 500MB worth of data"<<endl;
		break;
	}
	
	}
  //CASH DEPOSIT
	if(code=="*200#"){
		cout<<"Enter Mobile Money Pin"<<endl;
		cin>>npin;
	if(npin==pin){
		cout<<"Enter Amount"<<endl;
		cin>>acc;
        cout<<"Your new account balance is Ghc "<<acc+acc_b<<endl;
        break;
	}
    else{
    	cout<<"Invalid Option"<<endl;
    	attempts++;
    	if(attempts==4){
    		cout<<"Maximum number of attempts..."<<endl;
    		break;
		}
	}
}
 //CHANGING MOBILE MONEY PIN 
  if(code=="*300#"){
  	cout<<"Enter Old Pin"<<endl;
  	cin>>opin;
  	if(opin==pin){
  		cout<<"Enter New pin"<<endl;
  		cin>>npin;
  	cout<<"Your Pin has been changed successfully"<<endl;
  	break;
	}
	else{
		cout<<"Incorrect Pin.."<<endl;
		attempts++;
		if(attempts==4){
			cout<<"Attempts maximised"<<endl;
			break;
		}
	}
  }
  //SENDING AIRTIME
  if(code=="*530#"){
  string num;
  cout<<"Enter Amount"<<endl;
  cin>>acc;
  cout<<"Enter Receipient's number"<<endl;
  cin>>num;
  cout<<"Ghc "<<acc<<" worth of airtime has been sent to "<<num<<endl;
  break;
}
//TAKING A LOAN
 if(code=="*400#"){
 	cout<<"Enter Amount:"<<endl;
 	cin>>acc;
    cout<<"Enter pin to confirm"<<endl;
    cin>>npin;
    if(npin==pin){
    	cout<<"A loan of Ghc "<<acc<<" has been granted to you... Pay back ASAP"<<endl;
    	break;
	}
	else{
		cout<<"Invalid pin"<<endl;
		attempts++;
		if(attempts==4){
			cout<<"Maximum attempts reached..."<<endl;
			break;
		}
	}
 }
 //SAVINGS PLAN OPTION
 if(code=="*800#"){
 	cout<<"Select Your Savings Plan"<<endl;
 	cout<<"1)Daily Deposit"<<endl;
 	cout<<"2)Weekly Deposit"<<endl;
    cout<<"3)Monthly Deposit"<<endl;
    cin>>op;
    
 if(op==1){
 	cout<<"You can begin saving with at least Ghc 10 daily"<<endl;
 	break;
 }
 if(op==2){
 	cout<<"You can begin saving with at least Ghc 50 weekly"<<endl;
    break;
 }
 if(op==3){
 	cout<<"You can begin saving with at least Ghc 100 monthly"<<endl;
 	break;
 }
    
 }
 
 }
 
}
 	
 

